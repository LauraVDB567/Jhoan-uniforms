import React, { useState } from 'react';

const RecoverPassword = () => {
  const [email, setEmail] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validar que el email no esté vacío
    if (!email) {
      setErrorMessage('Por favor ingresa un correo electrónico.');
      return;
    }

    try {
      const response = await fetch('http://localhost:5000/recover-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),  // Enviar el correo al backend
      });

      const data = await response.json();

      if (response.ok) {
        setSuccessMessage('Correo enviado correctamente. Por favor revisa tu bandeja de entrada.');
        setEmail(''); // Limpiar el campo de correo electrónico
      } else {
        setErrorMessage(data.message || 'Hubo un problema al enviar el correo.');
      }
    } catch (error) {
      setErrorMessage('Hubo un problema al intentar enviar el correo.');
    }
  };

  return (
    <div className="recover-password-container">
      <h2>Recuperación de Contraseña</h2>

      {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
      {successMessage && <p style={{ color: 'green' }}>{successMessage}</p>}

      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="email">Correo Electrónico</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <button type="submit">Enviar Correo</button>
      </form>
    </div>
  );
};

export default RecoverPassword;