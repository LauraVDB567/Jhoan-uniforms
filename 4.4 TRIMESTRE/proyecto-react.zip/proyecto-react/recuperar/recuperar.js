const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
const port = 5000;

app.use(cors());
app.use(bodyParser.json());

const tokenStore = {}; 

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
  tls: {
    rejectUnauthorized: false,
  }
});

app.post('/recover-password', (req, res) => {
  const { email } = req.body;

  const token = jwt.sign({ email }, process.env.JWT_SECRET, { expiresIn: '1h' });

  tokenStore[token] = email;

  const recoveryLink = `http://localhost:3000/ResetPassword?token=${token}`;

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'Recuperación de Contraseña',
    text: `Haz clic en el siguiente enlace para restablecer tu contraseña: ${recoveryLink}`,
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log(error);
      return res.status(500).json({ message: 'Error al enviar el correo', error });
    }
    res.status(200).json({ message: 'Correo enviado correctamente' });
  });
});

app.post('/ResetPassword', (req, res) => {
  const { token, newPassword } = req.body;

  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(400).json({ message: 'Token no válido o expirado' });
    }

    const email = decoded.email;

    if (tokenStore[token] !== email) {
      return res.status(400).json({ message: 'Token no válido' });
    }

    delete tokenStore[token];

    res.status(200).json({ message: 'Contraseña cambiada correctamente' });
  });
});

app.listen(port, () => {
  console.log(`Servidor backend escuchando en http://localhost:${port}`);
});
