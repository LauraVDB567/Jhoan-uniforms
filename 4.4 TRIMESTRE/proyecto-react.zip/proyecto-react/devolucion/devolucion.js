const express = require('express');
const app = express();
const mysql = require('mysql');
const cors = require('cors');

app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "basedatos"
});

db.connect((err) => {
  if (err) {
    console.error('Error al conectar a la base de datos MySQL:', err);
  } else {
    console.log('Conectado a MySQL');
  }
});

app.get('/api/factura/numeroFactura/:numeroFactura', (req, res) => {
  const { numeroFactura } = req.params;

  const query = 'SELECT * FROM facturas WHERE numeroFactura = ?';
  db.query(query, [numeroFactura], (err, results) => {
    if (err) {
      console.error('Error al ejecutar la consulta para buscar factura:', err);
      return res.status(500).json({ message: 'Error al obtener la factura', error: err });
    }

    if (results.length > 0) {
      const factura = results[0];
      if (factura.productos) {
        factura.productos = JSON.parse(factura.productos);
      }
      return res.status(200).json(factura);
    } else {
      return res.status(404).json({ message: 'Factura no encontrada' });
    }
  });
});

app.post('/api/devolucion', (req, res) => {
  const { numeroFactura, nombre, telefono, productos, total, metodoPago,comentarios } = req.body;

  if (!numeroFactura || !nombre || !telefono || !productos || !total || !metodoPago || !comentarios) {
    console.error('Datos faltantes:', { numeroFactura, nombre, telefono, productos, total, metodoPago,comentarios });
    return res.status(400).json({ message: 'Faltan datos necesarios' });
  }

  const queryFactura = 'SELECT * FROM factura WHERE numeroFactura = ?';
  db.query(queryFactura, [numeroFactura], (err, results) => {
    if (err) {
      console.error('Error al ejecutar la consulta de factura:', err);
      return res.status(500).json({ message: 'Error al verificar la factura', error: err });
    }

    if (results.length === 0) {
      console.log('Factura no encontrada para el numeroFactura:', numeroFactura);
      return res.status(404).json({ message: 'Factura no encontrada' });
    }

    const factura = results[0];

    const queryDevolucion = 'INSERT INTO devoluciones (numeroFactura, nombre, telefono, productos, total, metodoPago,comentarios) VALUES (?, ?, ?, ?, ?, ?,?)';
    
    db.query(queryDevolucion, [numeroFactura, nombre, telefono, JSON.stringify(productos), total, metodoPago,comentarios], (err, results) => {
      if (err) {
        console.error('Error al registrar la devolución:', err);
        return res.status(500).json({ message: 'Error al registrar la devolución', error: err });
      }

      res.status(200).json({
        message: 'Devolución registrada con éxito',
        response: { numeroFactura, nombre, telefono, productos, total, metodoPago,comentarios }
      });
    });
  });
});

const PORT = process.env.PORT ||3002;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en el puerto ${PORT}`);
});



