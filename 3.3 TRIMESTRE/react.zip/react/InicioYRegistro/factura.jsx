import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import "./syle/factura.css";

const Factura = () => {
  const location = useLocation();
  const { carrito = [], total = 0 } = location.state || {};

  const [nombre, setNombre] = useState('');
  const [telefono, setTelefono] = useState('');
  const [cedula, setCedula] = useState('');
  const [fecha] = useState(new Date().toLocaleDateString());

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="factura">
      <header>
        <h1>Factura</h1>
      </header>

      <h2>Datos del Cliente</h2>
      <div className="datos-cliente">
        <input
          type="text"
          placeholder="Nombre"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
        />
        <input
          type="text"
          placeholder="Teléfono"
          value={telefono}
          onChange={(e) => setTelefono(e.target.value)}
        />
        <input
          type="text"
          placeholder="Cédula"
          value={cedula}
          onChange={(e) => setCedula(e.target.value)}
        />
        <input
          type="text"
          placeholder="Fecha"
          value={fecha}
          readOnly
        />
      </div>

      <h2>Productos Comprados</h2>
      <div className="lista-productos">
        {carrito.length > 20 ? (
          carrito.map((producto, index) => (
            <div className="producto" key={index}>
              <span>{producto.nombre}</span>
              <span>${producto.precio.toLocaleString()}</span>
            </div>
          ))
        ) : (
          <p>No hay productos en el carrito.</p>
        )}
      </div>

      <div className="total">
        <h3>Total a Pagar: ${total.toLocaleString()}</h3> 
      </div>

      <button onClick={handlePrint} className="btn-imprimir" disabled={!nombre || !telefono || !cedula}>
        Imprimir Factura
      </button>
    </div>
  );
};

export default Factura;
