import React, { Component } from 'react';
import './syle/crudA.css'; 

class Crud extends Component {
    constructor(props) {
        super(props);
        this.state = {
            items: JSON.parse(localStorage.getItem('items')) || [], 
            id: '',
            name: '',
            cedula: '',
            fecha: '',
            message: { text: '', type: '' },
            showForm: false, 
        };
    }

    handleInputChange = (e) => {
        this.setState({ [e.target.name]: e.target.value });
    };

    handleSubmit = (e) => {
        e.preventDefault();
        const { id, name, cedula, fecha, items } = this.state;

        if (!name || !id || !cedula || !fecha) {
            this.setState({ message: { text: 'Please fill in all fields.', type: 'error' } });
            return;
        }

        const newItem = { id: Date.now(), id, name, cedula, fecha };
        const updatedItems = [...items, newItem];

        this.setState({
            items: updatedItems,
            id: '',
            name: '',
            cedula: '',
            fecha: '',
            message: { text: 'Item added successfully!', type: 'success' },
        }, () => {
            localStorage.setItem('items', JSON.stringify(updatedItems)); 
        });
    };

    handleEdit = (id) => {
        const itemToEdit = this.state.items.find(item => item.id === id);
        this.setState({
            id: itemToEdit.id,
            name: itemToEdit.name,
            cedula: itemToEdit.cedula,
            fecha: itemToEdit.fecha,
            items: this.state.items.filter(item => item.id !== id),
        }, () => {
            localStorage.setItem('items', JSON.stringify(this.state.items)); 
        });
    };

    handleDelete = (id) => {
        const updatedItems = this.state.items.filter(item => item.id !== id);
        this.setState({
            items: updatedItems,
            message: { text: 'Item deleted successfully!', type: 'success' },
        }, () => {
            localStorage.setItem('items', JSON.stringify(updatedItems));
        });
    };

    toggleForm = () => {
        this.setState(prevState => ({ showForm: !prevState.showForm }));
    };

    render() {
        const { items, id, name, cedula, fecha, message, showForm } = this.state;

        return (
            <div className="container-crud">
                <div className="body-crud"></div>
                <div className="header-crud">
                    <h1><b>Listado de Usuarios</b></h1>
                    <button onClick={this.toggleForm} className="toggle-button">
                        {showForm ? 'Ocultar Campos' : 'Agregar Usuario'}
                    </button>
                </div>

                {showForm && (
                    <form onSubmit={this.handleSubmit}>
                        <div className="form-group-crud">
                            <label htmlFor="id">Id</label>
                            <input
                                type="text"
                                id="id"
                                name="id"
                                value={id}
                                onChange={this.handleInputChange}
                                required
                            />
                        </div>
                        <div className="form-group-crud">
                            <label htmlFor="name">Nombre</label>
                            <input
                                type="text"
                                id="name"
                                name="name"
                                value={name}
                                onChange={this.handleInputChange}
                                required
                            />
                        </div>
                        <div className="form-group-crud">
                            <label htmlFor="cedula">Cedula</label>
                            <input
                                type="text"
                                id="cedula"
                                name="cedula"
                                value={cedula}
                                onChange={this.handleInputChange}
                                required
                            />
                        </div>
                        <div className="form-group-crud">
                            <label htmlFor="fecha">Fecha</label>
                            <input
                                type="date"
                                id="fecha"
                                name="fecha"
                                value={fecha}
                                onChange={this.handleInputChange}
                                required
                            />
                        </div>
                        <button type="submit" className="button">Agregar</button>
                    </form>
                )}

                <table className="table-crud">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Nombre</th>
                            <th>Cedula</th>
                            <th>Fecha</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {items.map(item => (
                            <tr key={item.id}>
                                <td>{item.id}</td>
                                <td>{item.name}</td>
                                <td>{item.cedula}</td>
                                <td>{item.fecha}</td>
                                <td>
                                    <button className="edit-button-crud" onClick={() => this.handleEdit(item.id)}>Modificar</button>
                                    <button className="delete-button-crud" onClick={() => this.handleDelete(item.id)}>Eliminar</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>

                {message.text && (
                    <div className={`message ${message.type}`}>
                        {message.text}
                    </div>
                )}
            </div>
        );
    }
}

export default Crud;
