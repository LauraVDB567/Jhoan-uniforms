import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import "./syle/devolucion.css"

const Devoluciones = () => {
  const location = useLocation();
  const { carrito = [] } = location.state || {};
  const [productosADevolver, setProductosADevolver] = useState({});

  const handleChange = (productoId) => {
    setProductosADevolver((prev) => ({
      ...prev,
      [productoId]: !prev[productoId],
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const productosSeleccionados = Object.keys(productosADevolver).filter(
      (id) => productosADevolver[id]
    );

   
    console.log('Productos a devolver:', productosSeleccionados);
    alert('Solicitud de devolución enviada');
  };

  return (
    <div className="devoluciones">
      <h1>Solicitar Devolución</h1>
      <form onSubmit={handleSubmit}>
        <h2>Productos en el Carrito</h2>
        {carrito.length > 0 ? (
          carrito.map((producto) => (
            <div key={producto.id} className="producto">
              <input
                type="checkbox"
                checked={productosADevolver[producto.id] || false}
                onChange={() => handleChange(producto.id)}
              />
              <span>{producto.nombre} - ${producto.precio.toLocaleString()}</span>
            </div>
          ))
        ) : (
          <p>No hay productos en el carrito.</p>
        )}
        <button type="submit">Enviar Solicitud de Devolución</button>
      </form>
    </div>
  );
};

export default Devoluciones;
