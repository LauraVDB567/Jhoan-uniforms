import "./syle/principal.css";
import jhoan_icon from "../Archivos/Jhoan_Uniforms-removebg-preview.png";
import { Link } from "react-router-dom";

function Principal() {
    return (
        <>
         <div className="body-principal"></div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container-fluid">
                    <a className="navbar-brand">Johan Uniforms</a>
                    <button
                        className="navbar-toggler"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navbarNav"
                        aria-controls="navbarNav"
                        aria-expanded="false"
                        aria-label="Toggle navigation"
                    >
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarNav">
                        <ul className="navbar-nav ms-auto"> 
                            <li className="nav-item">
                                <Link className="nav-link" to="/Terminosycondiciones">Términos y Condiciones</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/InicioYRegistro">Inicio o Registro</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/devolucion">Devolución</Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div className="body-Principal">
                <div className="header-txt">
                    <h2>"Para poder iniciar sesión debe registrarse"</h2>
                    <p>
                        Sistema de información encargado únicamente de devoluciones
                    </p>
                    <Link className="nav-link" to="/vermas">
                        <button type="button" className="btn btn-info">Ver más</button>
                    </Link>
                </div>
                <div className="header-img">
                    <img src={jhoan_icon} alt="Johan Uniforms" />
                </div>
            </div>
            <br />
            <br />
            <div className="flooter-principal">
                <h1>Información de <br /> contacto</h1>
                <button type="button" className="btn btn-outline-info">WhatsApp</button>
                <button type="button" className="btn btn-outline-info">Teléfono</button>
                <button type="button" className="btn btn-outline-info">Correo Electrónico</button>
            </div>
        </>
    );
}

export default Principal;
