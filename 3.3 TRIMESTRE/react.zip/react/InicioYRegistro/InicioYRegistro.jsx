
import './syle/index.css';
import "./Principal";
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';


const InicioYRegistro = () => {
    const navigate = useNavigate();
    const [action, setAction] = useState("Registro");
    const [nombre, setNombre] = useState('');
    const [apellido, setApellido] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

   
    const adminCredentials = {
        email: "dkim44243@gmail.com",
        password: "twicebestgg"
    };

    const clientCredentials = {
        email: "maria89@gmail.com",
        password: "9089"
    };

    const handleSubmit = () => {
        if (action === "Registro") {
            if (nombre && apellido && email && password) {
                
                setAction("Inicio Sesión");
                setError('');
            } else {
                setError('Por favor, completa todos los campos.');
            }
        } else {
            if (email && password) {
                
                if (email === adminCredentials.email && password === adminCredentials.password) {
                    navigate('/crud'); 
                } else if (email === clientCredentials.email && password === clientCredentials.password) {
                    navigate('/carrito');
                } else {
                    setError('Credenciales incorrectas.');
                }
            } else {
                setError('Por favor, completa todos los campos.');
            }
        }
    };

    return (
        <div className="body-inicioyregistro">
            <div className="container">
                <div className="header">
                    <div className="text">{action}</div>
                    <div className="underline"></div>
                </div>
                <br />
                {action === "Inicio Sesión" ? null : (
                    <>
                        <div className="input">
                            <input 
                                type="text" 
                                placeholder="nombre" 
                                onChange={(e) => setNombre(e.target.value)} 
                            />
                        </div>
                        <br />
                        <div className="input">
                            <input 
                                type="text" 
                                placeholder="apellido" 
                                onChange={(e) => setApellido(e.target.value)} 
                            />
                        </div>
                    </>
                )}
                <br></br>
                <div className="inputs">
                    <div className="input">
                        <input 
                            type='email' 
                            placeholder='email' 
                            onChange={(e) => setEmail(e.target.value)} 
                        />
                    </div>
                </div>
                <br></br>
                <div className='inputs'>
                    <div className='input'>
                        <input 
                            type='password' 
                            placeholder='contraseña' 
                            onChange={(e) => setPassword(e.target.value)} 
                        />
                    </div>
                </div>
                {action === "Inicio Sesión" ? null : (
                    <div className='forgot-password'>
                        <span>¿Tienes cuenta?</span>
                    </div>
                )}
                <br />
                {error && <div className='error-message'>{error}</div>}
                <div className='submit-container'>
                    <center>
                        <div 
                            className={action === "Inicio Sesión" ? "submit gray" : "submit"} 
                            onClick={handleSubmit}
                        >
                            {action === "Inicio Sesión" ? 'Ingresar' : 'Registrar'}
                        </div>
                    </center>
                </div>
            </div>
        </div>
    );
};

export default InicioYRegistro;
