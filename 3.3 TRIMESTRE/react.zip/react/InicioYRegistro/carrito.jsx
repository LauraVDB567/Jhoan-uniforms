import React from 'react';
import { Link } from 'react-router-dom';
import './syle/carritocompras.css'; 
import azul from '../Archivos/azul-removebg-preview.png';
import saco_verde from '../Archivos/saco-removebg-preview.png';
import saco_negro from '../Archivos/saco_negro-removebg-preview.png';
import saco_gris from '../Archivos/saco gris.png';
import jardinera_azul from '../Archivos/jardinera_azul-removebg-preview.png';
import jardinera_gris from '../Archivos/jardinera gris.webp';
import jadrinera_clara from '../Archivos/jardinera_clara-removebg-preview.png';
import jardinera_oscura from '../Archivos/jardinera_de_rayas-removebg-preview.png';
import pantalon_negro from '../Archivos/pantalon_negro-removebg-preview - copia.png';
import pantalon_gris from '../Archivos/pantalon_gris-removebg-preview.png';
import pantalon_azul from '../Archivos/pantalon_azul-removebg-preview.png';
import pantalon_beigth from '../Archivos/beich-removebg-preview.png';
import medias_blancas from '../Archivos/medias_blancas-removebg-preview.png';
import medias_negras from '../Archivos/negra-removebg-preview.png';
import medias_azules from '../Archivos/media_azul-removebg-preview.png';
import medias_gris from '../Archivos/medias_gris-removebg-preview.png';
import zapatos_colegio from '../Archivos/image-removebg-preview.png';
import zapatos_2 from '../Archivos/zapatos.png';
import zapatos_blancos from '../Archivos/zapatos blancos.png';
import zapatos_deportivos from '../Archivos/tipo.png';

class CarritoCompras extends React.Component {
  constructor(props) {
    super(props);
    this.productos = [
      { nombre: 'Saco Color Verde', precio: 45000, imagen: saco_verde },
      { nombre: 'Saco De Color Negro', precio: 45000, imagen: saco_negro },
      { nombre: 'Saco De Color Azul', precio: 46000, imagen: azul },
      { nombre: 'Saco De Color Gris', precio: 43000, imagen: saco_gris },
      { nombre: 'Jardinera Azul', precio: 42000, imagen: jardinera_azul },
      { nombre: 'Jardinera De Rayas Oscura', precio: 45500, imagen: jardinera_oscura },
      { nombre: 'Jardinera De Rayas Clara', precio: 44000, imagen: jadrinera_clara },
      { nombre: 'Jardinera Gris', precio: 45000, imagen: jardinera_gris },
      { nombre: 'Pantalon Negro', precio: 40800, imagen: pantalon_negro },
      { nombre: 'Pantalon Gris', precio: 41000, imagen: pantalon_gris },
      { nombre: 'Pantalon Azul', precio: 41000, imagen: pantalon_azul },
      { nombre: 'Pantalon Beige', precio: 41000, imagen: pantalon_beigth },
      { nombre: 'Medias Blancas', precio: 9000, imagen: medias_blancas },
      { nombre: 'Medias Negras', precio: 75000, imagen: medias_negras },
      { nombre: 'Medias Azules', precio: 85000, imagen: medias_azules },
      { nombre: 'Medias Grises', precio: 80000, imagen: medias_gris },
      { nombre: 'Zapatos De Diario', precio: 50000, imagen: zapatos_colegio },
      { nombre: 'Zapatos De Diario Estilo 2', precio: 51000, imagen: zapatos_2 },
      { nombre: 'Zapatos Blancos', precio: 47800, imagen: zapatos_blancos },
      { nombre: 'Zapatos Blancos Deportivos', precio: 50000, imagen: zapatos_deportivos },
    ];

    this.carrito = [];
  }

  agregarAlCarrito = (producto) => {
    this.carrito.push(producto);
    this.forceUpdate();
  };

  calcularTotal = () => {
    return this.carrito.reduce((total, producto) => total + producto.precio, 0);
  };

  formatCurrency = (amount) => {
    return amount.toLocaleString('es-CO', { style: 'currency', currency: 'COP' });
  };

  render() {
    const total = this.calcularTotal();

    return (
      <div className="contenedor">
      <div className="body-carrito">
        <header>
          <h1>Carrito de Compras</h1>
        </header>
</div>
        <div className="contenedor-items">
          {this.productos.map((producto, index) => (
            <div className="item" key={index}>
              <img src={producto.imagen} alt={producto.nombre} className="img-item" />
              <div className="titulo-item">{producto.nombre}</div>
              <div className="precio-item">{this.formatCurrency(producto.precio)}</div>
              <button className="boton-item" onClick={() => this.agregarAlCarrito(producto)}>Agregar al Carrito</button>
            </div>
          ))}
        </div>
        
        <h3>Productos en el Carrito</h3>
        <div className="carrito">
          {this.carrito.map((producto, index) => (
            <div className="carrito-item" key={index}>
              <img src={producto.imagen} alt={producto.nombre} style={{ width: '50px', height: '50px', marginRight: '10px' }} />
              <div className="carrito-item-titulo">{producto.nombre}</div>
              <div className="carrito-item-precio">{this.formatCurrency(producto.precio)}</div>
            </div>
          ))}
          <div className="carrito-total">
            <div className="fila">
              <span>Total:</span>
              <span>{this.formatCurrency(total)}</span>
            </div>

            <Link to={{
              pathname: "/factura",
              state: { carrito: this.carrito, total }
            }}>
              <button className="btn-pagar" disabled={this.carrito.length === 0}>
                Generar Factura
              </button>
            </Link>
          </div>
        </div>
      </div>
    );
  }
}

export default CarritoCompras;
